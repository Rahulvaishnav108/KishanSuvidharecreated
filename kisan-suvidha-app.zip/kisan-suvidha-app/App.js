// App.js - Main Entry Point for Kisan Suvidha Redesigned
import React, { useEffect, useState, useCallback } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { Provider as PaperProvider, DefaultTheme } from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { I18nextProvider } from 'react-i18next';
import i18n from './src/services/TranslationService';
import OfflineStorage from './src/services/OfflineStorage';

// Screens
import OnboardingScreen from './src/screens/OnboardingScreen';
import HomeScreen from './src/components/HomeScreen';
import WeatherScreen from './src/screens/WeatherScreen';
import MarketScreen from './src/screens/MarketScreen';
import AdvisoryScreen from './src/screens/AdvisoryScreen';
import SettingsScreen from './src/screens/SettingsScreen';

// Voice Navigator Component
import VoiceNavigator from './src/components/VoiceNavigator';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

// Custom theme with farmer-friendly colors
const theme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    primary: '#2E7D32', // Green for agriculture
    accent: '#FF9800', // Orange for alerts
    background: '#F5F5F5',
    surface: '#FFFFFF',
    text: '#212121',
    disabled: '#BDBDBD',
    placeholder: '#757575',
  },
  roundness: 8,
};

// Bottom Tab Navigator
function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName;

          if (route.name === 'Home') {
            iconName = focused ? 'home' : 'home-outline';
          } else if (route.name === 'Weather') {
            iconName = focused ? 'weather-partly-cloudy' : 'weather-cloudy';
          } else if (route.name === 'Market') {
            iconName = focused ? 'cart' : 'cart-outline';
          } else if (route.name === 'Advisory') {
            iconName = focused ? 'lightbulb' : 'lightbulb-outline';
          } else if (route.name === 'Settings') {
            iconName = focused ? 'cog' : 'cog-outline';
          }

          return <Icon name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: theme.colors.primary,
        tabBarInactiveTintColor: '#757575',
        tabBarStyle: {
          height: 60,
          paddingBottom: 8,
          paddingTop: 8,
        },
        tabBarLabelStyle: {
          fontSize: 12,
          fontWeight: '600',
        },
        headerStyle: {
          backgroundColor: theme.colors.primary,
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
          fontSize: 18,
        },
      })}
    >
      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{ title: 'होम / Home' }}
      />
      <Tab.Screen
        name="Weather"
        component={WeatherScreen}
        options={{ title: 'मौसम / Weather' }}
      />
      <Tab.Screen
        name="Market"
        component={MarketScreen}
        options={{ title: 'बाज़ार / Market' }}
      />
      <Tab.Screen
        name="Advisory"
        component={AdvisoryScreen}
        options={{ title: 'सलाह / Advisory' }}
      />
      <Tab.Screen
        name="Settings"
        component={SettingsScreen}
        options={{ title: 'सेटिंग / Settings' }}
      />
    </Tab.Navigator>
  );
}

// Main App Component
export default function App() {
  const [isFirstLaunch, setIsFirstLaunch] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    checkFirstLaunch();
  }, []);

  const checkFirstLaunch = useCallback(async () => {
    try {
      const hasLaunched = await OfflineStorage.getData('hasLaunched');
      setIsFirstLaunch(hasLaunched === null);
      setIsLoading(false);
    } catch (error) {
      console.error('Error checking first launch:', error);
      setIsLoading(false);
    }
  }, []);

  const handleOnboardingComplete = useCallback(async () => {
    try {
      await OfflineStorage.saveData('hasLaunched', 'true');
      setIsFirstLaunch(false);
    } catch (error) {
      console.error('Error saving onboarding complete:', error);
    }
  }, []);

  if (isLoading) {
    return null; // Or a loading screen
  }

  return (
    <I18nextProvider i18n={i18n}>
      <PaperProvider theme={theme}>
        <NavigationContainer>
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            {isFirstLaunch ? (
              <Stack.Screen name="Onboarding">
                {props => (
                  <OnboardingScreen
                    {...props}
                    onComplete={handleOnboardingComplete}
                  />
                )}
              </Stack.Screen>
            ) : (
              <Stack.Screen name="Main" component={MainTabs} />
            )}
          </Stack.Navigator>
          {/* Voice Navigator - Always Available */}
          <VoiceNavigator />
        </NavigationContainer>
      </PaperProvider>
    </I18nextProvider>
  );
}
