// src/components/VoiceNavigator.js - Voice Navigation System
import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Alert,
} from 'react-native';
import { Text, Portal, Modal } from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Voice from '@react-native-voice/voice';
import Tts from 'react-native-tts';
import { useNavigation } from '@react-navigation/native';
import { useTranslation } from 'react-i18next';

const VoiceNavigator = () => {
  const [isListening, setIsListening] = useState(false);
  const [recognizedText, setRecognizedText] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const animationRef = useRef(null);

  const navigation = useNavigation();
  const { t, i18n } = useTranslation();

  const onSpeechStart = useCallback(() => {
    setIsListening(true);
  }, []);

  const onSpeechEnd = useCallback(() => {
    setIsListening(false);
  }, []);

  const onSpeechResults = useCallback((event) => {
    const text = event.value[0]?.toLowerCase() || '';
    setRecognizedText(text);
    processVoiceCommand(text);
  }, []);

  const onSpeechError = useCallback((error) => {
    console.error('Speech Error:', error);
    setIsListening(false);
    speak(t('voice.error') || 'Voice error occurred');
  }, [t]);

  const speak = useCallback((text) => {
    if (text) {
      Tts.speak(text);
    }
  }, []);

  const processVoiceCommand = useCallback((command) => {
    if (!command) return;

    // Command mapping for multiple languages
    const commandMap = {
      // Hindi commands
      'होम': 'Home',
      'घर': 'Home',
      'मौसम': 'Weather',
      'बाजार': 'Market',
      'बाज़ार': 'Market',
      'मंडी': 'Market',
      'सलाह': 'Advisory',
      'सेटिंग': 'Settings',

      // English commands
      'home': 'Home',
      'weather': 'Weather',
      'market': 'Market',
      'mandi': 'Market',
      'advisory': 'Advisory',
      'advice': 'Advisory',
      'settings': 'Settings',

      // Punjabi commands
      'ਘਰ': 'Home',
      'ਮੌਸਮ': 'Weather',
      'ਮੰਡੀ': 'Market',
      'ਸਲਾਹ': 'Advisory',
    };

    // Find matching command
    let targetScreen = null;
    for (const [key, value] of Object.entries(commandMap)) {
      if (command.includes(key)) {
        targetScreen = value;
        break;
      }
    }

    if (targetScreen) {
      navigation.navigate(targetScreen);
      speak(t(`voice.navigating_to.${targetScreen.toLowerCase()}`) || `Navigating to ${targetScreen}`);
      setShowModal(false);
    } else {
      speak(t('voice.command_not_understood') || 'Command not understood');
    }
  }, [navigation, speak, t]);

  const startPulseAnimation = useCallback(() => {
    if (animationRef.current) {
      animationRef.current.stop();
    }
    animationRef.current = Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.3,
          duration: 800,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 800,
          useNativeDriver: true,
        }),
      ])
    );
    animationRef.current.start();
  }, [pulseAnim]);

  const stopPulseAnimation = useCallback(() => {
    if (animationRef.current) {
      animationRef.current.stop();
      animationRef.current = null;
    }
  }, []);

  useEffect(() => {
    // Initialize Voice Recognition
    Voice.onSpeechStart = onSpeechStart;
    Voice.onSpeechEnd = onSpeechEnd;
    Voice.onSpeechResults = onSpeechResults;
    Voice.onSpeechError = onSpeechError;

    // Initialize TTS
    Tts.setDefaultLanguage(i18n.language === 'hi' ? 'hi-IN' : 'en-IN');

    return () => {
      Voice.destroy().then(Voice.removeAllListeners);
      stopPulseAnimation();
    };
  }, [onSpeechStart, onSpeechEnd, onSpeechResults, onSpeechError, i18n.language, stopPulseAnimation]);

  useEffect(() => {
    if (isListening) {
      startPulseAnimation();
    } else {
      stopPulseAnimation();
    }
  }, [isListening, startPulseAnimation, stopPulseAnimation]);

  const startListening = async () => {
    try {
      setShowModal(true);
      setRecognizedText('');
      await Voice.start(i18n.language === 'hi' ? 'hi-IN' : 'en-IN');
      speak(t('voice.listening'));
    } catch (error) {
      console.error('Start Listening Error:', error);
      Alert.alert(t('voice.error'), t('voice.permission_required'));
    }
  };

  const stopListening = async () => {
    try {
      await Voice.stop();
      setShowModal(false);
    } catch (error) {
      console.error('Stop Listening Error:', error);
    }
  };

  return (
    <>
      {/* Floating Voice Button */}
      <TouchableOpacity
        style={styles.floatingButton}
        onPress={startListening}
        activeOpacity={0.8}
      >
        <Icon name="microphone" size={32} color="#FFFFFF" />
      </TouchableOpacity>

      {/* Voice Recognition Modal */}
      <Portal>
        <Modal
          visible={showModal}
          onDismiss={stopListening}
          contentContainerStyle={styles.modalContainer}
        >
          <View style={styles.modalContent}>
            <Animated.View
              style={[
                styles.microphoneContainer,
                { transform: [{ scale: pulseAnim }] },
              ]}
            >
              <Icon
                name={isListening ? 'microphone' : 'microphone-off'}
                size={64}
                color={isListening ? '#2E7D32' : '#FF5252'}
              />
            </Animated.View>

            <Text style={styles.statusText}>
              {isListening ? t('voice.listening') : t('voice.tap_to_speak')}
            </Text>

            {recognizedText ? (
              <View style={styles.recognizedContainer}>
                <Text style={styles.recognizedLabel}>{t('voice.you_said')}:</Text>
                <Text style={styles.recognizedText}>{recognizedText}</Text>
              </View>
            ) : null}

            <View style={styles.commandsContainer}>
              <Text style={styles.commandsTitle}>{t('voice.try_saying')}:</Text>
              <Text style={styles.commandText}>
                "{t('voice.commands.weather')}"
              </Text>
              <Text style={styles.commandText}>
                "{t('voice.commands.market')}"
              </Text>
              <Text style={styles.commandText}>
                "{t('voice.commands.advisory')}"
              </Text>
            </View>

            <TouchableOpacity
              style={styles.closeButton}
              onPress={stopListening}
            >
              <Text style={styles.closeButtonText}>{t('voice.close')}</Text>
            </TouchableOpacity>
          </View>
        </Modal>
      </Portal>
    </>
  );
};

const styles = StyleSheet.create({
  floatingButton: {
    position: 'absolute',
    bottom: 80,
    right: 20,
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#2E7D32',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    zIndex: 1000,
  },
  modalContainer: {
    backgroundColor: 'white',
    padding: 20,
    margin: 20,
    borderRadius: 16,
    elevation: 5,
  },
  modalContent: {
    alignItems: 'center',
  },
  microphoneContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  statusText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#212121',
    marginBottom: 16,
  },
  recognizedContainer: {
    backgroundColor: '#E8F5E9',
    padding: 16,
    borderRadius: 8,
    marginBottom: 20,
    width: '100%',
  },
  recognizedLabel: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  recognizedText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#2E7D32',
  },
  commandsContainer: {
    backgroundColor: '#FFF3E0',
    padding: 16,
    borderRadius: 8,
    width: '100%',
    marginBottom: 20,
  },
  commandsTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#E65100',
    marginBottom: 8,
  },
  commandText: {
    fontSize: 14,
    color: '#666',
    marginVertical: 4,
  },
  closeButton: {
    backgroundColor: '#2E7D32',
    paddingHorizontal: 32,
    paddingVertical: 12,
    borderRadius: 8,
  },
  closeButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default VoiceNavigator;
