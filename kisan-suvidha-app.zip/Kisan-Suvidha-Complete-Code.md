# Kisan Suvidha Redesigned - Complete React Native Code

This document contains the complete source code for the redesigned Kisan Suvidha app with voice navigation, offline support, and farmer-friendly UI.

## Project Structure

```
KisanSuvidha-Redesigned/
├── App.js
├── package.json
├── src/
│   ├── components/
│   │   ├── VoiceNavigator.js
│   │   ├── HomeScreen.js
│   │   ├── WeatherCard.js
│   │   ├── MarketPriceCard.js
│   │   └── CropAdvisoryCard.js
│   ├── screens/
│   │   ├── OnboardingScreen.js
│   │   ├── WeatherScreen.js
│   │   ├── MarketScreen.js
│   │   ├── AdvisoryScreen.js
│   │   └── SettingsScreen.js
│   ├── services/
│   │   ├── OfflineStorage.js
│   │   ├── TranslationService.js
│   │   └── WeatherService.js
│   └── locales/
│       ├── hi.json
│       ├── en.json
│       ├── pa.json
│       └── ta.json
```

---

## 1. package.json

```json
{
  "name": "kisan-suvidha-redesigned",
  "version": "2.0.0",
  "description": "Redesigned Kisan Suvidha app with voice navigation and offline support",
  "main": "index.js",
  "scripts": {
    "android": "react-native run-android",
    "ios": "react-native run-ios",
    "start": "react-native start",
    "test": "jest",
    "lint": "eslint ."
  },
  "dependencies": {
    "react": "18.2.0",
    "react-native": "0.73.0",
    "@react-navigation/native": "^6.1.9",
    "@react-navigation/stack": "^6.3.20",
    "@react-navigation/bottom-tabs": "^6.5.11",
    "react-native-voice": "^3.2.4",
    "@react-native-async-storage/async-storage": "^1.21.0",
    "react-native-tts": "^4.1.0",
    "i18next": "^23.7.6",
    "react-i18next": "^13.5.0",
    "axios": "^1.6.2",
    "react-native-vector-icons": "^10.0.3",
    "react-native-paper": "^5.11.3",
    "react-native-gesture-handler": "^2.14.0",
    "react-native-reanimated": "^3.6.0",
    "react-native-safe-area-context": "^4.8.0",
    "react-native-screens": "^3.29.0",
    "react-native-permissions": "^4.0.3",
    "react-native-geolocation-service": "^5.3.1",
    "moment": "^2.29.4",
    "react-native-modal": "^13.0.1"
  },
  "devDependencies": {
    "@babel/core": "^7.23.5",
    "@babel/preset-env": "^7.23.5",
    "@babel/runtime": "^7.23.5",
    "@react-native/babel-preset": "^0.73.18",
    "@react-native/metro-config": "^0.73.2",
    "metro-react-native-babel-preset": "^0.77.0",
    "babel-jest": "^29.7.0",
    "jest": "^29.7.0"
  },
  "engines": {
    "node": ">=18"
  }
}
```

---

## 2. App.js - Main Entry Point

```javascript
// App.js - Main Entry Point for Kisan Suvidha Redesigned
import React, { useEffect, useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { Provider as PaperProvider, DefaultTheme } from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { I18nextProvider } from 'react-i18next';
import i18n from './src/services/TranslationService';
import OfflineStorage from './src/services/OfflineStorage';

// Screens
import OnboardingScreen from './src/screens/OnboardingScreen';
import HomeScreen from './src/components/HomeScreen';
import WeatherScreen from './src/screens/WeatherScreen';
import MarketScreen from './src/screens/MarketScreen';
import AdvisoryScreen from './src/screens/AdvisoryScreen';
import SettingsScreen from './src/screens/SettingsScreen';

// Voice Navigator Component
import VoiceNavigator from './src/components/VoiceNavigator';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

// Custom theme with farmer-friendly colors
const theme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    primary: '#2E7D32', // Green for agriculture
    accent: '#FF9800', // Orange for alerts
    background: '#F5F5F5',
    surface: '#FFFFFF',
    text: '#212121',
    disabled: '#BDBDBD',
    placeholder: '#757575',
  },
  roundness: 8,
};

// Bottom Tab Navigator
function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName;

          if (route.name === 'Home') {
            iconName = focused ? 'home' : 'home-outline';
          } else if (route.name === 'Weather') {
            iconName = focused ? 'weather-partly-cloudy' : 'weather-cloudy';
          } else if (route.name === 'Market') {
            iconName = focused ? 'cart' : 'cart-outline';
          } else if (route.name === 'Advisory') {
            iconName = focused ? 'lightbulb' : 'lightbulb-outline';
          } else if (route.name === 'Settings') {
            iconName = focused ? 'cog' : 'cog-outline';
          }

          return <Icon name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: theme.colors.primary,
        tabBarInactiveTintColor: '#757575',
        tabBarStyle: {
          height: 60,
          paddingBottom: 8,
          paddingTop: 8,
        },
        tabBarLabelStyle: {
          fontSize: 12,
          fontWeight: '600',
        },
        headerStyle: {
          backgroundColor: theme.colors.primary,
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
          fontSize: 18,
        },
      })}
    >
      <Tab.Screen 
        name="Home" 
        component={HomeScreen}
        options={{ title: 'होम / Home' }}
      />
      <Tab.Screen 
        name="Weather" 
        component={WeatherScreen}
        options={{ title: 'मौसम / Weather' }}
      />
      <Tab.Screen 
        name="Market" 
        component={MarketScreen}
        options={{ title: 'बाज़ार / Market' }}
      />
      <Tab.Screen 
        name="Advisory" 
        component={AdvisoryScreen}
        options={{ title: 'सलाह / Advisory' }}
      />
      <Tab.Screen 
        name="Settings" 
        component={SettingsScreen}
        options={{ title: 'सेटिंग / Settings' }}
      />
    </Tab.Navigator>
  );
}

// Main App Component
export default function App() {
  const [isFirstLaunch, setIsFirstLaunch] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    checkFirstLaunch();
  }, []);

  const checkFirstLaunch = async () => {
    try {
      const hasLaunched = await OfflineStorage.getData('hasLaunched');
      setIsFirstLaunch(hasLaunched === null);
      setIsLoading(false);
    } catch (error) {
      console.error('Error checking first launch:', error);
      setIsLoading(false);
    }
  };

  const handleOnboardingComplete = async () => {
    await OfflineStorage.saveData('hasLaunched', 'true');
    setIsFirstLaunch(false);
  };

  if (isLoading) {
    return null; // Or a loading screen
  }

  return (
    <I18nextProvider i18n={i18n}>
      <PaperProvider theme={theme}>
        <NavigationContainer>
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            {isFirstLaunch ? (
              <Stack.Screen name="Onboarding">
                {props => (
                  <OnboardingScreen
                    {...props}
                    onComplete={handleOnboardingComplete}
                  />
                )}
              </Stack.Screen>
            ) : (
              <Stack.Screen name="Main" component={MainTabs} />
            )}
          </Stack.Navigator>
          {/* Voice Navigator - Always Available */}
          <VoiceNavigator />
        </NavigationContainer>
      </PaperProvider>
    </I18nextProvider>
  );
}
```

---

## 3. src/components/VoiceNavigator.js

```javascript
// src/components/VoiceNavigator.js - Voice Navigation System
import React, { useState, useEffect } from 'react';
import {
  View,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Alert,
} from 'react-native';
import { Text, Portal, Modal } from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Voice from '@react-native-voice/voice';
import Tts from 'react-native-tts';
import { useNavigation } from '@react-navigation/native';
import { useTranslation } from 'react-i18next';

const VoiceNavigator = () => {
  const [isListening, setIsListening] = useState(false);
  const [recognizedText, setRecognizedText] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [pulseAnim] = useState(new Animated.Value(1));
  
  const navigation = useNavigation();
  const { t, i18n } = useTranslation();

  useEffect(() => {
    // Initialize Voice Recognition
    Voice.onSpeechStart = onSpeechStart;
    Voice.onSpeechEnd = onSpeechEnd;
    Voice.onSpeechResults = onSpeechResults;
    Voice.onSpeechError = onSpeechError;

    // Initialize TTS
    Tts.setDefaultLanguage(i18n.language === 'hi' ? 'hi-IN' : 'en-IN');
    
    return () => {
      Voice.destroy().then(Voice.removeAllListeners);
    };
  }, []);

  useEffect(() => {
    if (isListening) {
      startPulseAnimation();
    }
  }, [isListening]);

  const startPulseAnimation = () => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.3,
          duration: 800,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 800,
          useNativeDriver: true,
        }),
      ])
    ).start();
  };

  const onSpeechStart = () => {
    setIsListening(true);
  };

  const onSpeechEnd = () => {
    setIsListening(false);
  };

  const onSpeechResults = (event) => {
    const text = event.value[0].toLowerCase();
    setRecognizedText(text);
    processVoiceCommand(text);
  };

  const onSpeechError = (error) => {
    console.error('Speech Error:', error);
    setIsListening(false);
    speak(t('voice.error'));
  };

  const speak = (text) => {
    Tts.speak(text);
  };

  const processVoiceCommand = (command) => {
    // Command mapping for multiple languages
    const commandMap = {
      // Hindi commands
      'होम': 'Home',
      'घर': 'Home',
      'मौसम': 'Weather',
      'बाजार': 'Market',
      'बाज़ार': 'Market',
      'मंडी': 'Market',
      'सलाह': 'Advisory',
      'सेटिंग': 'Settings',
      
      // English commands
      'home': 'Home',
      'weather': 'Weather',
      'market': 'Market',
      'mandi': 'Market',
      'advisory': 'Advisory',
      'advice': 'Advisory',
      'settings': 'Settings',
      
      // Punjabi commands
      'ਘਰ': 'Home',
      'ਮੌਸਮ': 'Weather',
      'ਮੰਡੀ': 'Market',
      'ਸਲਾਹ': 'Advisory',
    };

    // Find matching command
    let targetScreen = null;
    for (const [key, value] of Object.entries(commandMap)) {
      if (command.includes(key)) {
        targetScreen = value;
        break;
      }
    }

    if (targetScreen) {
      navigation.navigate(targetScreen);
      speak(t(`voice.navigating_to.${targetScreen.toLowerCase()}`));
      setShowModal(false);
    } else {
      speak(t('voice.command_not_understood'));
    }
  };

  const startListening = async () => {
    try {
      setShowModal(true);
      setRecognizedText('');
      await Voice.start(i18n.language === 'hi' ? 'hi-IN' : 'en-IN');
      speak(t('voice.listening'));
    } catch (error) {
      console.error('Start Listening Error:', error);
      Alert.alert(t('voice.error'), t('voice.permission_required'));
    }
  };

  const stopListening = async () => {
    try {
      await Voice.stop();
      setShowModal(false);
    } catch (error) {
      console.error('Stop Listening Error:', error);
    }
  };

  return (
    <>
      {/* Floating Voice Button */}
      <TouchableOpacity
        style={styles.floatingButton}
        onPress={startListening}
        activeOpacity={0.8}
      >
        <Icon name="microphone" size={32} color="#FFFFFF" />
      </TouchableOpacity>

      {/* Voice Recognition Modal */}
      <Portal>
        <Modal
          visible={showModal}
          onDismiss={stopListening}
          contentContainerStyle={styles.modalContainer}
        >
          <View style={styles.modalContent}>
            <Animated.View
              style={[
                styles.microphoneContainer,
                { transform: [{ scale: pulseAnim }] },
              ]}
            >
              <Icon
                name={isListening ? 'microphone' : 'microphone-off'}
                size={64}
                color={isListening ? '#2E7D32' : '#FF5252'}
              />
            </Animated.View>

            <Text style={styles.statusText}>
              {isListening ? t('voice.listening') : t('voice.tap_to_speak')}
            </Text>

            {recognizedText ? (
              <View style={styles.recognizedContainer}>
                <Text style={styles.recognizedLabel}>{t('voice.you_said')}:</Text>
                <Text style={styles.recognizedText}>{recognizedText}</Text>
              </View>
            ) : null}

            <View style={styles.commandsContainer}>
              <Text style={styles.commandsTitle}>{t('voice.try_saying')}:</Text>
              <Text style={styles.commandText}>
                "{t('voice.commands.weather')}"
              </Text>
              <Text style={styles.commandText}>
                "{t('voice.commands.market')}"
              </Text>
              <Text style={styles.commandText}>
                "{t('voice.commands.advisory')}"
              </Text>
            </View>

            <TouchableOpacity
              style={styles.closeButton}
              onPress={stopListening}
            >
              <Text style={styles.closeButtonText}>{t('voice.close')}</Text>
            </TouchableOpacity>
          </View>
        </Modal>
      </Portal>
    </>
  );
};

const styles = StyleSheet.create({
  floatingButton: {
    position: 'absolute',
    bottom: 80,
    right: 20,
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#2E7D32',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    zIndex: 1000,
  },
  modalContainer: {
    backgroundColor: 'white',
    padding: 20,
    margin: 20,
    borderRadius: 16,
    elevation: 5,
  },
  modalContent: {
    alignItems: 'center',
  },
  microphoneContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  statusText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#212121',
    marginBottom: 16,
  },
  recognizedContainer: {
    backgroundColor: '#E8F5E9',
    padding: 16,
    borderRadius: 8,
    marginBottom: 20,
    width: '100%',
  },
  recognizedLabel: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  recognizedText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#2E7D32',
  },
  commandsContainer: {
    backgroundColor: '#FFF3E0',
    padding: 16,
    borderRadius: 8,
    width: '100%',
    marginBottom: 20,
  },
  commandsTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#E65100',
    marginBottom: 8,
  },
  commandText: {
    fontSize: 14,
    color: '#666',
    marginVertical: 4,
  },
  closeButton: {
    backgroundColor: '#2E7D32',
    paddingHorizontal: 32,
    paddingVertical: 12,
    borderRadius: 8,
  },
  closeButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default VoiceNavigator;
```

---

*[Document continues with remaining component files - Due to length, I'll create the file now]*
